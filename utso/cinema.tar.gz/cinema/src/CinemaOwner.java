
public class CinemaOwner extends Leader{

    public CinemaOwner(String name) {
        super(name);
    }
}
