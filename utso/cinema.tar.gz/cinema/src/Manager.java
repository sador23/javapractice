
public class Manager extends Leader{

    public Manager(String name) {
        super(name);
    }

}
